const { expect } = require('chai');
const sinon = require('sinon');
const DronesMedicationsController = require('../../src/controllers/DronesMedicationsController');
const DronesMedications = require('../../src/models/DronesMedications');

describe('DronesMedicationsController', () => {

});
